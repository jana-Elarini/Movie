import 'package:flutter/material.dart';
import 'package:moviedetails/model/category.dart';

class MoviePoster extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    var args= ModalRoute.of(context)?.settings.arguments as Movie;
    return Stack(
      alignment: Alignment.center,
      children: [
        Image.network(
          'https://image.tmdb.org/t/p/w500', // Replace with actual image URL
          width: double.infinity,
          fit: BoxFit.cover,
        ),
        IconButton(
          icon: Icon(Icons.play_circle_fill, size: 64, color: Colors.white),
          onPressed: () {
            // Play movie
          },
        ),
      ],
    );
  }
}
