import 'package:flutter/material.dart';

class MovieRating extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        children: [
          Icon(Icons.star, color: Colors.amber),
          SizedBox(width: 4),
          Text('7.7', style: TextStyle(fontSize: 18)),
        ],
      ),
    );
  }
}
