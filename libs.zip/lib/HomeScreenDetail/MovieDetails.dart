import 'package:flutter/material.dart';

class MovieDetails extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Dora and the Lost City of Gold',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 8),
          Row(
            children: [
              Text('2019'),
              SizedBox(width: 10),
              Text('PG-13'),
              SizedBox(width: 10),
              Text('2h 7m'),
            ],
          ),
          SizedBox(height: 8),
          Wrap(
            spacing: 8.0,
            children: [
              Chip(label: Text('Action')),
              Chip(label: Text('Adventure')),
              Chip(label: Text('Family')),
            ],
          ),
          SizedBox(height: 16),
          Text(
            'Having spent most of her life exploring the jungle, '
                'nothing could prepare Dora for her most dangerous adventure yet — high school.',
          ),
        ],
      ),
    );
  }
}
