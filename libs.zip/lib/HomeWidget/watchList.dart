import 'package:flutter/material.dart';


import '../MyTheme/myTheme.dart';

class WatchListWidget extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return Container(
      color: MyTheme.greylightColor,
    );
  }
}